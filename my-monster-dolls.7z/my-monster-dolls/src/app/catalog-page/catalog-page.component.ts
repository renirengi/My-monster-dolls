import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catalog-page',
  templateUrl: './catalog-page.component.html',
  styleUrls: ['./catalog-page.component.css']
})
export class CatalogPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
