import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StartPageComponent } from './start-page/start-page.component';
import { MainPageComponent } from './main-page/main-page.component';
import { UserPageComponent } from './user-page/user-page.component';
import { CatalogPageComponent } from './catalog-page/catalog-page.component';
import { startWith } from 'rxjs';

const routes: Routes = [
{ path: 'start-page-component', component: StartPageComponent },
{ path: 'main-page-component', component: MainPageComponent },
{ path: 'user-page-component', component: UserPageComponent },
{ path: 'catalog-page-component', component: CatalogPageComponent },];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
